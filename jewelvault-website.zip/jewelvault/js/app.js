/* ===== JEWELVAULT — APP JS ===== */

function renderDashboard() {
  const products = DB.getProducts();
  const total = products.length;
  const value = products.reduce((a, p) => a + (p.price * p.stock), 0);
  const lowOut = products.filter(p => p.stock <= (p.alert || 5)).length;
  const margins = products.filter(p => p.cost > 0).map(p => (p.price - p.cost) / p.price * 100);
  const avgMargin = margins.length ? Math.round(margins.reduce((a, b) => a + b, 0) / margins.length) : 0;

  if (document.getElementById('stat-total')) document.getElementById('stat-total').textContent = total;
  if (document.getElementById('stat-value')) document.getElementById('stat-value').textContent = fmtPrice(value);
  if (document.getElementById('stat-low')) document.getElementById('stat-low').textContent = lowOut;
  if (document.getElementById('stat-margin')) document.getElementById('stat-margin').textContent = avgMargin + '%';

  renderAlerts(products);
  renderCatBars(products);
  renderActivity();
  renderRecentProducts(products);
}

function renderAlerts(products) {
  const el = document.getElementById('alerts-container');
  if (!el) return;
  const issues = products.filter(p => p.stock <= (p.alert || 5));
  el.innerHTML = issues.map(p => {
    const type = p.stock === 0 ? 'danger' : 'warning';
    const msg = p.stock === 0 ? `"${p.name}" is out of stock!` : `"${p.name}" is running low — only ${p.stock} left`;
    return `<div class="alert ${type}"><span>${msg}</span><a href="pages/inventory.html" style="font-size:12px;color:inherit;opacity:0.7;">View →</a></div>`;
  }).join('');
}

function renderCatBars(products) {
  const el = document.getElementById('cat-bars');
  if (!el) return;
  const cats = ['Watch', 'Chain', 'Bracelet', 'Ring', 'Pendant', 'Earring'];
  const counts = cats.map(c => products.filter(p => p.cat === c).reduce((a, p) => a + p.stock, 0));
  const max = Math.max(...counts, 1);
  el.innerHTML = cats.map((c, i) => `
    <div class="cat-bar-row">
      <div class="cat-bar-label">${c}</div>
      <div class="cat-bar-track"><div class="cat-bar-fill" style="width:${Math.round(counts[i]/max*100)}%"></div></div>
      <div class="cat-bar-count">${counts[i]}</div>
    </div>`).join('');
}

function renderActivity() {
  const el = document.getElementById('activity-list');
  if (!el) return;
  const activity = DB.getActivity().slice(-8).reverse();
  if (!activity.length) {
    el.innerHTML = '<div class="empty-text" style="font-size:13px;color:var(--muted);">No activity yet.</div>';
    return;
  }
  el.innerHTML = activity.map(a => `
    <div class="activity-item">
      <span class="activity-msg">${a.msg}</span>
      <span class="activity-time">${a.time}</span>
    </div>`).join('');
}

function renderRecentProducts(products) {
  const tbody = document.getElementById('recent-tbody');
  if (!tbody) return;
  const recent = products.slice(-6).reverse();
  if (!recent.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px;color:var(--muted);">No products yet.</td></tr>';
    return;
  }
  tbody.innerHTML = recent.map(p => {
    const thumb = p.media && p.media.length ? `<img src="${p.media[0].url}" style="width:38px;height:38px;border-radius:8px;object-fit:cover;">` : `<div class="product-thumb">${catEmoji(p.cat)}</div>`;
    return `<tr>
      <td><div class="product-cell">${thumb}<div><div class="product-name">${p.name}</div><div class="product-sku">${p.sku}</div></div></div></td>
      <td><span class="badge ${catBadgeClass(p.cat)}">${p.cat}</span></td>
      <td>${fmtPrice(p.price)}</td>
      <td>${p.stock}</td>
      <td><span class="badge ${stockBadgeClass(p)}">${stockStatus(p)}</span></td>
    </tr>`;
  }).join('');
}
