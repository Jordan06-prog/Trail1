/* ===== JEWELVAULT — DATA LAYER (localStorage) ===== */

const DEFAULT_PRODUCTS = [
  { id:1, name:'Gold chain 22K', sku:'CH-001', cat:'Chain', mat:'22K Gold', price:45000, cost:38000, stock:12, alert:5, weight:10, purity:'22K', desc:'Classic handcrafted gold chain, suitable for daily wear.', media:[] },
  { id:2, name:'Diamond solitaire ring', sku:'RG-001', cat:'Ring', mat:'18K White Gold', price:120000, cost:95000, stock:3, alert:5, weight:4, purity:'18K', desc:'Brilliant-cut solitaire diamond in 18K white gold setting.', media:[] },
  { id:3, name:'Silver bracelet 925', sku:'BR-001', cat:'Bracelet', mat:'925 Silver', price:3500, cost:2200, stock:20, alert:5, weight:15, purity:'925', desc:'Sterling silver bracelet with box chain design.', media:[] },
  { id:4, name:'Pearl pendant gold', sku:'PD-001', cat:'Pendant', mat:'Gold + Pearl', price:8500, cost:6000, stock:4, alert:5, weight:3, purity:'22K', desc:'South sea pearl pendant with 22K gold bail.', media:[] },
  { id:5, name:'Gold stud earrings', sku:'ER-001', cat:'Earring', mat:'22K Gold', price:15000, cost:11000, stock:8, alert:5, weight:2, purity:'22K', desc:'Classic gold stud earrings, lightweight and elegant.', media:[] },
  { id:6, name:'Chronograph watch', sku:'WA-001', cat:'Watch', mat:'Stainless Steel', price:25000, cost:18000, stock:2, alert:3, weight:120, purity:'-', desc:'Swiss movement chronograph with sapphire crystal glass.', media:[] },
  { id:7, name:'Ruby bangle set', sku:'BR-002', cat:'Bracelet', mat:'22K Gold + Ruby', price:65000, cost:50000, stock:1, alert:2, weight:25, purity:'22K', desc:'Set of 4 ruby-encrusted gold bangles.', media:[] },
  { id:8, name:'Hoop earrings gold', sku:'ER-002', cat:'Earring', mat:'18K Gold', price:9500, cost:7000, stock:6, alert:5, weight:3, purity:'18K', desc:'Medium hoop earrings in 18K yellow gold.', media:[] },
];

const DB = {
  getProducts() {
    const raw = localStorage.getItem('jv_products');
    if (!raw) { this.setProducts(DEFAULT_PRODUCTS); return DEFAULT_PRODUCTS; }
    return JSON.parse(raw);
  },
  setProducts(products) {
    localStorage.setItem('jv_products', JSON.stringify(products));
  },
  addProduct(product) {
    const products = this.getProducts();
    const id = Date.now();
    products.push({ ...product, id });
    this.setProducts(products);
    this.addActivity(`Added: ${product.name}`);
    return id;
  },
  updateProduct(id, updates) {
    const products = this.getProducts();
    const idx = products.findIndex(p => p.id === id);
    if (idx === -1) return false;
    const old = products[idx];
    products[idx] = { ...old, ...updates };
    this.setProducts(products);
    const diff = (updates.stock !== undefined) ? updates.stock - old.stock : 0;
    if (diff !== 0) this.addActivity(`${old.name} stock ${diff > 0 ? '+' : ''}${diff}`);
    else this.addActivity(`Updated: ${updates.name || old.name}`);
    return true;
  },
  deleteProduct(id) {
    const products = this.getProducts();
    const p = products.find(x => x.id === id);
    if (!p) return false;
    this.setProducts(products.filter(x => x.id !== id));
    this.addActivity(`Deleted: ${p.name}`);
    return true;
  },
  getActivity() {
    const raw = localStorage.getItem('jv_activity');
    return raw ? JSON.parse(raw) : [];
  },
  addActivity(msg) {
    const activity = this.getActivity();
    activity.push({ msg, time: new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }) });
    if (activity.length > 50) activity.shift();
    localStorage.setItem('jv_activity', JSON.stringify(activity));
  }
};

function stockStatus(p) {
  if (p.stock === 0) return 'Out of Stock';
  if (p.stock <= (p.alert || 5)) return 'Low Stock';
  return 'In Stock';
}

function stockBadgeClass(p) {
  const s = stockStatus(p);
  if (s === 'In Stock') return 'badge-in-stock';
  if (s === 'Low Stock') return 'badge-low-stock';
  return 'badge-out-of-stock';
}

function catBadgeClass(cat) {
  const map = { Watch:'badge-watch', Chain:'badge-chain', Bracelet:'badge-bracelet', Ring:'badge-ring', Pendant:'badge-pendant', Earring:'badge-earring' };
  return map[cat] || '';
}

function fmtPrice(n) {
  return '₹' + Number(n || 0).toLocaleString('en-IN');
}

function catEmoji(cat) {
  const map = { Watch:'⌚', Chain:'🔗', Bracelet:'💎', Ring:'💍', Pendant:'🏅', Earring:'✨' };
  return map[cat] || '◆';
}

function showToast(msg, type = 'success') {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}
